package com.example.ndwa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class insteactions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insteactions);
    }
}